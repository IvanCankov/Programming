// An Exception thrown by 'Stick'.
//
public class StickBreaksException extends Exception {

    //TODO: define missing parts of this class.
}
