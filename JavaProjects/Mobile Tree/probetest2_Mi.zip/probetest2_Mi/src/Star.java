// Leaf node of a mobile. The actual decoration of a mobile.
// A 'Star' has a specified weight of type 'int', that can not be changed after
// initialisation. 'Star' implements 'Decoration'.
//
public class Star // implements Decoration // TODO: uncomment clause.
{

    //TODO: define missing parts of the class.

    public Star(int weight) {

        // TODO: implement constructor.
    }

    // Returns a readable representation of 'this' with the
    // symbol '*' followed by the weight of this star.
    public String toString() {

        // TODO: implement method.
        return "";
    }
}

// TODO: define additional classes if needed (either here or in a separate file).
