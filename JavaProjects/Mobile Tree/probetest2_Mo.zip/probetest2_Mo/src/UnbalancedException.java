// An Exception thrown by 'BalancedStick'
//
public class UnbalancedException extends Exception {

    //TODO: define missing parts of this class.
}
